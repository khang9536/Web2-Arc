## Implementation Plan: Arc Wallet (neobank-style USDC app)

### Summary
A responsive USDC app for people who have never used crypto, working on phone and desktop with an English UI. Users sign in with email or Google, pick a unique permanent @username, and see one Total balance in dollars with their assets right below it. They send to an @username, a scanned QR code or a pasted address, and receive by showing a QR code. They can also swap between USDC, EURC and cirBTC, put money in Savings to earn yield, and learn in Explore (top coins, gainers and losers, memecoins, news). Users hold their own keys (Circle user-controlled wallets); every money action shows a simple Circle "Confirm" screen. They never see wallet addresses as the main way to pay, or which network their money is on. Testnet only.

### Architecture
- Blockchain: Arc Testnet is the home network (USDC is gas, so users never hold a separate gas token). Ethereum Sepolia and Base Sepolia are used behind the scenes for funding and moving money.
- Wallet: Circle user-controlled wallets with Email OTP and Google sign-in, created as EOA wallets on Arc Testnet, Ethereum Sepolia and Base Sepolia in one step (same address on all three; the build must verify this).
  - Circle shows a transaction preview with a Confirm button for transfers (no PIN for email and Google). The text is customized so "To" shows the @username, and contract actions get plain titles that show token amounts, such as "Swap 10 USDC to EURC".
  - Whether wallet creation shows an extra step is verified during the login step.
  - If a session expires (about 60 minutes), the user is asked to sign in again.
- Backend: a small TypeScript server (Hono on Bun) with `/api/*` routes, proxied by Vite in dev. It holds the Circle API key. It also keeps one WebSocket connection to Binance's public market data (no key needed) and pushes live prices to the browser. It creates Circle challenges (create wallets, transfer, contract execution, typed-data signing), reads balances and activity, and serves Explore data. Sessions use httpOnly cookies. Money routes take the user and wallet from the session only, never from request fields.
- Database: Postgres in Docker with a named volume.
  - `users`: Circle user id, email, unique lowercase @username (3 to 20 characters of a-z, 0-9 and underscore, reserved words blocked, never updated), wallet addresses.
  - `recipients`: each user's past recipients, used for the new-recipient warning.
  - Cache tables for market and news data if needed.
- Send: by @username (database lookup), by QR scan (camera) or by pasted address. It uses Circle's direct transfer challenge on Arc Testnet, which is simpler and more reliable than the App Kit path. The recipient is stored after a successful send. Network: an @username or a pasted address sends on Arc. A scanned QR code from an outside wallet can include the network; the app reads it and, for USDC, delivers there through the unified balance, without ever naming the network. EURC and cirBTC send on Arc only in the first version. What to do when the QR's network cannot receive the chosen token is asked of the user before step 9.
- Receive: a QR code that encodes the @username in an app link format. The wallet address sits under "Show wallet address". A short guide explains how to get free test USDC.
- QR scanning needs a secure context, so it must be tested in the preview. If the camera is unavailable, a paste field is shown for @username or address.
- App Kit features (Swap, Savings and automatic funding): App Kit (`@circle-fin/app-kit`, installed) runs in the browser with a Viem adapter. `src/lib/ucwProvider.ts` is an EIP-1193 compatibility layer that turns App Kit's transaction and typed-data requests into Circle challenges the user confirms, and sends read calls to the public RPC.
  - Swap: `estimateSwap` then `swap`, between USDC, EURC and cirBTC on Arc Testnet (the only tokens Arc supports for swaps). Whether testnet cirBTC has enough liquidity is checked at the Swap step.
  - Savings: `earn.exploreVaults`, quotes, `deposit`, `withdraw`.
  - Automatic cross-network funding (no screen of its own; the user never sees a network, an "add money" step or a "move money" step): CCTP `bridge` moves EURC and cirBTC between networks only inside Send, Swap and Savings when the balance on Arc is short; FAST speed by default.
  - Unified balance: `unifiedBalance.deposit`, `spend`, `getBalances` for USDC, run automatically by the app, never as a user-visible feature.
  - Biggest risk: this layer is unproven. It is tested right after Send (a small swap) before any other feature depends on it. If it fails, the build stops and we decide together. A single App Kit action may need two or more Confirm screens; the app explains this with a progress indicator.
- cirBTC (Circle Wrapped Bitcoin): added as a third asset on Arc Testnet (token address `0xf0C4a4CE82A5746AbAAd9425360Ab04fbBA432BF`, 8 decimals; confirm both from token data in code, not from memory).
  - Supported: shown in Assets and Total balance, swapped between USDC, EURC and cirBTC, sent and received like other assets. cirBTC exists on Arc Testnet and Ethereum Sepolia; in the first version only the Arc balance counts. If the user later agrees at step 18 to add CCTP funding, cirBTC held on Ethereum Sepolia can be brought to Arc automatically; that route must be verified then, because a token existing on a network does not guarantee its bridge route is live, and the build stops and asks if it does not work.
  - Not supported: Savings (Earn takes only USDC and EURC), and the unified balance (USDC only). cirBTC and EURC use CCTP for automatic funding instead. Borrow (borrowing USDC against cirBTC) is postponed and not in this plan.
  - Testnet cirBTC has no real value. Circle's docs say testnet cirBTC can be obtained from the Circle faucet; this is checked early, and swapping on Arc is the fallback only if the user agrees.
- Automatic funding (later steps): the user never adds money, moves money or picks a network. When a send, swap or savings deposit needs more on Arc than the Arc wallet holds:
  - USDC: the app first spends from the unified balance to Arc. If the USDC sits in wallets on a Sepolia network, the app first deposits it into the unified balance (this can take minutes on testnet), then spends. The user only ever sees one USDC balance.
  - EURC and cirBTC: in the first version only the balance on Arc is counted and shown, and nothing is moved automatically. At step 18 the build agent asks the user whether to add automatic CCTP funding for them (bringing the token to Arc when it sits on another network).
  - The user sees a plain "Preparing your funds (step 1 of 3)" screen and stays on it until the funds are ready, then the original action continues. Each step still needs a Circle Confirm (titles are customized and never name a network), so a send with short funds can need 2 to 3 Confirms. There is no Move money, Add money or Withdraw screen.
  - Any fee for moving funds between networks appears as one plain "Fee" line in the token amount on the review screen, without saying where it comes from.
  - Automatic funding runs only when needed, not in the background. Arc-only use works first.
- Total balance and Assets (Home):
  - Total balance shows one number only: the dollar value of everything. It adds USDC held in the user's wallets on all three networks, USDC pooled in the unified balance (never shown as a separate section), EURC and cirBTC held on Arc (other networks are ignored unless the user later agrees to add CCTP funding at step 18), and the Savings position. No network is ever named in the UI. EURC is converted to dollars at the EUR rate from Binance and cirBTC at the Bitcoin price from Binance (pair names stay on the server). No breakdown boxes sit under it. The only extra is a small "Moving money" note, shown only while money is in transit.
  - The assets sit as cards right under the balance on Home and show the three tokens by ticker: USDC, EURC and cirBTC. Each card has one combined token amount, never split by network (`USDC  1,000.00`, `EURC  200.00`, `cirBTC  0.0025`) with its dollar value in small text below. Tapping a card opens that asset's detail. If a rate is unavailable, show only the token amount and note "excludes EURC" or "excludes cirBTC" in the total.
  - Savings is not an asset row. It has its own card on Home with the amount saved and interest earned, and it still counts in Total balance.
  - A hide-balance eye icon and a small "Testnet" badge are always visible.
- Money display rules:
  - Total balance and all dollar values use `$1,234.56`. Asset cards show the ticker (USDC, EURC, cirBTC) with the token amount and the dollar value in small text.
  - Two decimals normally, more for sub-cent amounts and Savings interest. Never round balances up. All math via `@/onchain-money`, no floating point.
  - Explore uses adaptive decimals for tiny memecoin prices, compact numbers (`$1.2T`), and a sign plus arrow (not only color) for changes.
  - cirBTC amounts show up to 8 decimals with trailing zeros removed (for example `0.0025`), always as a token amount first and the dollar value second.
  - US-style formatting with `Intl.NumberFormat`, through one shared money component.
- Layout: responsive. Phones get a bottom navigation (Home, Savings, Explore, Activity). Desktop gets a left sidebar with a wider content area; Send, Swap and Savings open as dialogs.
- Explore (read-only information, real-world data, not testnet):
  - Prices come from Binance public market data (no API key): a REST snapshot for the first load (`data-api.binance.vision`, 24-hour ticker for all pairs) and a live WebSocket stream of all-market mini tickers (about one update per second). The server keeps a single stream connection, caches the latest values, and pushes updates to browsers, so users never call Binance directly. If Binance returns rate-limit errors (429), the server backs off.
  - Top coins: a fixed list of about 30 of the largest coins, ordered by market cap by us (for example BTC, ETH, BNB), with live Binance prices. The order can become outdated over time and is easy to edit in one file.
  - Gainers and Losers: computed on the server from all USDT pairs using the 24-hour percent change, ignoring stablecoins, leveraged tokens and pairs with very low trading volume.
  - Memecoins: a fixed list we choose (for example DOGE, SHIB, PEPE, BONK, WIF, FLOKI) with live Binance prices.
  - The word "USDT" never appears in the UI. Binance quotes prices in USDT, but the app shows only the coin symbol (for example `BTC`, never `BTCUSDT` or `BTC/USDT`) and prices as dollars (`$67,250.00`). Tether stays in the top-coin list, shown by its name "Tether" and its logo only, never with the ticker USDT. Binance has no USDT-against-USDT pair, so Tether's price is shown as about `$1.00`, derived on the server from a Binance USDC pair or fixed; this is checked at the Explore step and the user is asked if it cannot be done sensibly. Tether is not included in Gainers and Losers (its price barely moves). Pair names stay inside the server. Binance prices are treated as dollar prices; the user accepted a very small difference from true USD prices, and the UI does not mention USDT or add a disclaimer about it.
  - Names and logos come from a static table in the app (and the already installed `@web3icons/react` for common coins), because Binance only returns symbols. Only coins listed on Binance can appear.
  - Binance may be blocked in some regions or from the server's location; this is checked first when Explore starts, and the build stops and asks if it is blocked. Binance's terms for showing its data (including any attribution) are checked at the same time.
  - News: RSS feeds from CoinDesk and Cointelegraph, parsed on the server, cached for a few minutes, with links out to the original articles.
  - Small "What is this?" explainers on terms like market cap, stablecoin and memecoin. A short "this is information, not financial advice" note.
- Earn on testnet: documented for Arc Testnet, but whether testnet vaults exist is unconfirmed. The Savings screen calls `exploreVaults`. If none come back, it shows a friendly "coming soon on testnet" state.
- Send warning (a warning only, never a block; there are no spending limits and no amount threshold): before sending, the review screen shows a "Double-check this" notice with a "Send anyway" button only when the recipient is new, meaning an @username or address this user has never sent to before.
  - The server keeps a per-user list of past recipients to know this; a recipient is added after a successful send.
  - The notice names the recipient and the token amount in plain words (for example "You're about to send 250 USDC to @minh for the first time" or "0.0025 cirBTC") and reminds the user that transfers cannot be undone. It never shows a dollar amount.
  - Send review and success screens also show the token amount, not dollars.
- Safety basics: validate every amount and recipient on the server, use idempotency keys, wait for a final transaction state before reporting success, and rate limit login and send routes.
- Frontend: React, Tailwind, framer-motion, sonner, lucide-react (already installed). Add `qrcode.react` (show QR codes) and a camera QR scanner library. Circle's Web SDK handles sign-in and confirmation screens. ConnectKit and wagmi are not used for the app's own users.

### Files to Create/Modify
Setup and config
1. `package.json` - add server deps (Hono, Postgres client), `qrcode.react`, a camera QR scanner library, `fast-xml-parser`; scripts to run server and Vite together.
2. `compose.yaml` - Postgres 18 with a named volume and a health check.
3. `vite.config.ts` - proxy `/api` to the backend; keep `nodePolyfills()`.
4. `.env` - server secrets (`CIRCLE_API_KEY`, `DATABASE_URL`, session secret) and public values under `VITE_` (`VITE_CIRCLE_APP_ID`). Make sure `.gitignore` covers `.env*`.

Backend
5. `server/index.ts` - app entry, cookie sessions, error handling, route mounting.
6. `server/db.ts` and `server/schema.sql` - tables, unique and immutable username, past recipients, migrations on start.
7. `server/circle.ts` - user-controlled wallets client: device tokens, user initialization, wallet creation, challenges, balances, transaction status.
8. `server/routes/auth.ts` - session creation from Circle login, sign out.
9. `server/routes/users.ts` - username availability, claim, lookup for Send.
10. `server/routes/money.ts` - send challenge, fee estimate, activity, recipients.
11. `server/routes/contract.ts` - contract execution and typed-data signing challenges for the compatibility layer.
12. `server/routes/explore.ts`, `server/market.ts`, `server/news.ts` - Binance REST snapshot and WebSocket feed with cache and live push to browsers, fixed top-coin and memecoin lists, gainers/losers, EUR and Bitcoin rates for Total balance, RSS news.

Frontend
13. `src/lib/api.ts` - typed fetch helpers for `/api`.
14. `src/lib/circle.ts` - Web SDK setup (`getDeviceId`, login callback, `setAuthentication`, promise-based `execute`, confirmation text customization).
15. `src/lib/ucwProvider.ts` - EIP-1193 compatibility layer for App Kit.
16. `src/lib/appkit.ts` - App Kit instance, adapter, chain and token constants. `src/lib/funding.ts` - automatic funding plan (USDC through the unified balance, EURC and cirBTC through CCTP).
17. `src/lib/format.ts` and `src/components/Money.tsx` - shared money formatting.
18. `src/context/AuthContext.tsx` - session, current user, sign out.
19. `src/components/auth/SignIn.tsx`, `src/components/auth/ChooseUsername.tsx` - email OTP, Google, username with live availability and "cannot be changed" notice.
20. `src/App.tsx` - responsive shell (bottom nav and sidebar), page switching, Toaster, Testnet badge.
21. `src/hooks/useBalances.ts`, `src/hooks/useActivity.ts` - balances across networks, Total balance, per-asset amounts and dollar values, Savings position, activity in plain language.
22. `src/pages/Home.tsx` and `src/components/AssetList.tsx` - Total balance (one dollar number), asset cards (USDC, EURC, cirBTC) and the Savings card, Send / Receive / Swap buttons only (Total balance is not tappable for a network breakdown), Explore teaser, recent activity.
23. `src/pages/Send.tsx`, `src/components/QrScanner.tsx`, `src/components/DoubleCheckSheet.tsx` - recipient search, QR scan, amount, warning, success.
24. `src/pages/Receive.tsx` - QR code, copy username, address, test money guide.
25. `src/pages/Swap.tsx` - token pickers for USDC, EURC and cirBTC with flip, estimate, routing disclosure.
26. `src/pages/Savings.tsx` - vault list, quotes, deposit, withdraw, empty state.
27. `src/pages/Explore.tsx`, `src/components/explore/*` - Top coins, Gainers and Losers, Memecoins, News, coin detail, explainers.
28. `src/pages/AssetDetail.tsx`, `src/pages/Settings.tsx`, `src/components/PreparingFunds.tsx` - asset detail, username, email, address, sign out, and the "Preparing your funds" progress screen used by automatic funding.
29. `src/components/ui/*` - BottomNav, Sidebar, Sheet/Dialog, AmountInput, TxStatus, EmptyState, Skeleton.
30. `src/index.css`, `tailwind.config.js` - neobank theme tokens.
31. `AGENTS.md` - project memory (stack, wallet model, database, how to run).

### Working Agreement (how the build will run)
- The build agent works in small steps. After each step it runs typecheck and lint, checks the preview, and reports what changed.
- It then waits for the user's go-ahead before starting the next step. If anything is ambiguous, it asks first instead of guessing.
- If a step fails, it fixes that step before moving on, so errors stay isolated.
- Before starting any step that touches an open risk (listed under "Open risks to watch", for example steps 11, 12, 16, 17 and 18), the build agent explains the risk and asks the user how to handle it, and proceeds only after the answer. If the step then fails or the result is not as expected, it stops and asks again.
- Always ask the user before any decision that changes the plan. If something does not work (for example the compatibility layer between Circle wallets and App Kit, no testnet Earn vaults, or no cirBTC liquidity), the build agent stops and asks. It never switches to another approach on its own.

### Build Sequence
Each step ends with a typecheck, lint and a check in the preview, then a pause for the user's go-ahead.
1. Server and database: Postgres in Docker, backend skeleton, schema, Vite proxy, `/api/health`.
2. Email login: Circle email OTP, session cookie, wallet creation on the three testnets; confirm the same address and whether any setup step appears.
3. Google login on the same session.
4. Username: availability check, claim at signup, permanent.
5. Wallets check: balance on Arc, wallet addresses stored.
6. App shell and Home: responsive layout, Total balance (one dollar number), asset cards for USDC, EURC and cirBTC with dollar values, Savings card, big action buttons, Testnet badge, hide-balance.
7. Receive: QR with @username, copy, address, test money guide.
8. Send by @username: asset picker (USDC, EURC, cirBTC), lookup, amount, "Double-check this" warning for a new recipient only, customized Confirm screen, final-state wait, success screen showing the token amount sent.
9. Send by QR and pasted address: the QR scanner reads the network when the code includes it (for example the `ethereum:0x...@chainId` format); a pasted address sends on Arc. Before building, ask the user what to do when the code's network cannot receive the chosen token (for example cirBTC to a network where it does not exist); the question was not settled yet.
10. Activity.
11. Compatibility check: build `ucwProvider.ts` and run a small Swap estimate and swap. Pause and decide together if it fails.
12. Swap screen completed with all three tokens; check whether testnet cirBTC has liquidity and tell the user the result.
13. Explore part 1: first check that Binance market data is reachable and ask the user if it is blocked; then Top coins and coin detail with live prices.
14. Explore part 2: Gainers and Losers, Memecoins.
15. Explore part 3: News and explainers.
16. Savings (Earn).
17. Automatic funding for USDC: unified balance deposit and spend inside Send, Swap and Savings, with the "Preparing your funds" screen. No Add money, Withdraw or Move screens.
18. Ask the user whether to add automatic funding for EURC and cirBTC with CCTP. Only if the answer is yes: build it for the networks where each token exists, verify each route (EURC across the three networks, cirBTC between Ethereum Sepolia and Arc Testnet), and ask the user if one does not work. If the answer is no, skip this step.
19. Polish: plain wording, errors, layout check on phone, tablet and desktop, project memory update.

### Done When
- [ ] A new user signs in with email or Google, picks a unique @username that cannot be changed, and lands on Home with wallets created.
- [ ] Home shows Total balance as one dollar number, with cards for USDC, EURC and cirBTC (token amount plus small dollar value) and a Savings card right under it, on both phone and desktop. Savings counts toward Total balance.
- [ ] Amounts follow the display rules, with a visible Testnet badge and a hide-balance toggle.
- [ ] Receive shows a QR code with the @username; the address is available but secondary.
- [ ] Send works by @username, QR scan and pasted address, with the customized Confirm screen showing the @username.
- [ ] Sending to a first-time recipient shows a "Double-check this" warning with "Send anyway"; sending to a recipient used before shows none, whatever the amount. The warning, the review and the success screen show the token amount (for example 250 USDC or 0.0025 cirBTC), not dollars.
- [ ] Swap converts between USDC, EURC and cirBTC after showing an estimate (or clearly tells the user when a cirBTC pair has no testnet liquidity).
- [ ] cirBTC can be sent and received, amounts show up to 8 decimals, and it counts toward Total balance in dollars.
- [ ] Savings lists vaults with deposit and withdraw, or shows a clear "not available on testnet yet" state.
- [ ] Explore shows top coins, gainers and losers, memecoins and recent news from the server, with prices updating live about once per second and no API key in the browser.
- [ ] Money held on another network is used automatically for sends, swaps and savings: USDC through the unified balance. EURC and cirBTC count and show on Arc only unless the user agrees at step 18 to add CCTP funding. The user never sees a network, and there is no Move money, Add money or Withdraw screen.
- [ ] Home has only Send, Receive and Swap buttons. Total balance is not tappable for a network breakdown, and no screen shows networks, Add money, Withdraw or Move.
- [ ] The words Gateway, CCTP, attestation, EOA, gas, chain and signature do not appear in the main UI, and "USDT" (including pair names such as BTCUSDT) appears nowhere in the app.
- [ ] No secret is in browser code, no money route trusts an address or user id from the request, and everything targets testnet only.

### Setup the user needs to do
- Circle Console: an API key and the User Controlled App ID.
- Email OTP: SMTP settings in Console (Mailtrap sandbox works for testing).
- Google: an OAuth client ID set up in Circle Console and Google Cloud.
- Allowed domain: `ivdn4sp2u49t4f5en98y9.preview.studio.arc.io`.
- Explore needs no key (Binance public market data and RSS news).

### Decisions already made
- User-controlled wallets with email and Google; Confirm screens are accepted.
- No spending limits and no amount threshold; only a first-time recipient gets a "Double-check this" warning, shown with the token amount.
- UI is English and responsive for phone and desktop.
- Total balance is only a dollar number. The asset cards (USDC, EURC, cirBTC, each with a small dollar value) and a separate Savings card sit on Home under it; Savings counts toward the total.
- cirBTC is included in Assets, Total balance, Swap and Send/Receive. It works with CCTP (not with unified balance or Earn), so it is brought to Arc automatically when held on Ethereum Sepolia. Borrow is postponed for later.
- EURC and cirBTC work with CCTP but not with the unified balance; only USDC uses the unified balance. In the first version EURC and cirBTC count and show on Arc only; the user decides at step 18 whether to add CCTP funding for them.
- Chains stay completely hidden. Unified balance and CCTP have no screens: the app uses them automatically when funds are short. USDC shows as one balance; EURC and cirBTC show their Arc balance only. Sending defaults to Arc (an @username or a pasted address always sends on Arc); a scanned QR code from an outside wallet can carry its network, which the app reads without naming it. Receive mentions no other network, the user waits on the "Preparing your funds" screen, and any funding fee shows as one plain "Fee" line.
- Explore prices come live from Binance and are shown as `$` dollar prices (very small difference from true USD accepted); the word USDT never appears in the app, and Tether is shown in Top coins by name and logo only (no USDT ticker), at about $1.00, and kept out of Gainers and Losers.
- Pause after each step.

### Open risks to watch
- The compatibility layer between Circle wallets and App Kit is unproven; it is tested at step 11 before other features depend on it.
- Some App Kit actions may need two or more Confirm screens.
- Testnet cirBTC may have thin swap liquidity, and the cirBTC bridge route between Ethereum Sepolia and Arc Testnet must be verified. Circle's docs say the faucet provides testnet cirBTC; this is confirmed first.
- Testnet Earn vaults may not exist; Savings has an empty state.
- Automatic funding can need 2 to 3 Confirm screens and minutes of waiting on testnet, and the EURC and cirBTC bridge routes must be verified; it ships late and shows progress.
- Email delivery depends on the SMTP provider you choose.
- Binance market data may be blocked from some regions or from the server, and the fixed top-coin order can become outdated; both are raised with the user at the Explore steps.

## Ready to build?
