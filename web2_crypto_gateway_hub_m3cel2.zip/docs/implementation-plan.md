Plan đã được cập nhật, cả 9 chỗ sửa đều lưu thành công vào `arc-studio-plans/PLAN.md`.

**Đã ghi vào plan**
- **EURC và cirBTC, làm theo cách C:** bản đầu chỉ tính và hiện số dư trên Arc, không tự chuyển gì. Ở bước 18, tôi hỏi bạn có muốn thêm tự chuyển bằng CCTP không. Nếu không thì bỏ bước 18.
- **Send mặc định trên Arc:** @username hoặc địa chỉ dán vào luôn gửi trên Arc.
- **Quét QR:** nếu mã QR của ví ngoài có kèm mạng (định dạng `ethereum:0x...@chainId`), app đọc mạng từ đó mà không nói tên mạng. USDC được gửi thẳng tới mạng đó qua unified balance. EURC và cirBTC chỉ gửi trên Arc ở bản đầu.

**Về câu bạn chưa rõ, tôi giải thích đơn giản hơn**
Ví dụ: bạn quét mã QR của một người dùng ví ngoài, mã này ghi mạng là Base Sepolia. Bạn muốn gửi cirBTC. Nhưng cirBTC chỉ có trên Arc Testnet và Ethereum Sepolia, nên **người nhận ở Base Sepolia không nhận được cirBTC**. Khi đó app cần làm một trong hai việc:
- Báo "This address can't receive cirBTC" và để bạn chọn token khác.
- Hoặc hỏi bạn có muốn gửi trên Arc thay vào đó không (rủi ro là người nhận không thấy tiền ở ví của họ).

Tình huống này hiếm, nên tôi để lại hỏi bạn trước khi build bước 9, ghi rõ trong plan. Bạn không cần quyết bây giờ.

Plan hiện khớp với mọi quyết định bạn đã chốt. Nếu bạn thấy ổn, có thể phê duyệt để bắt đầu bước 1.

## Ready to build?
